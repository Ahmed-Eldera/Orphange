abstract class AppIterator {
  bool hasNext();
  dynamic next();
}
