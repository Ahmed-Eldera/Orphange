// lib/controllers/commands/command.dart
abstract class Command {
  Future<void> execute();
}
