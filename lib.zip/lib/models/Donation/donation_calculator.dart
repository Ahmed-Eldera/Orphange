// donation_calculator.dart

abstract class DonationCalculator {
  double getCost();
  String getDescription();
}
