abstract class Iterator {
  bool hasNext();
  dynamic next();
}
